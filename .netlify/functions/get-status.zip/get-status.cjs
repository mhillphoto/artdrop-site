var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/get-status.js
var get_status_exports = {};
__export(get_status_exports, {
  default: () => handler
});
module.exports = __toCommonJS(get_status_exports);
var import_blobs = require("@netlify/blobs");
var ALL_PERSONAS = [
  "Elena Vasquez",
  "Marcus Cole",
  "Janelle Torres",
  "David Okonkwo",
  "Own Artwork"
];
var ALL_TESTERS = ["Kim", "Cassidy", "Marshall", "Mark", "Lisa", "Michael"];
var CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
  "Content-Type": "application/json"
};
async function handler(req) {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: CORS });
  }
  if (req.method !== "GET") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), {
      status: 405,
      headers: CORS
    });
  }
  const personaStatus = {};
  for (const p of ALL_PERSONAS) {
    personaStatus[p] = null;
  }
  const testerStatus = {};
  for (const t of ALL_TESTERS) {
    testerStatus[t] = { persona: null, completed: false };
  }
  try {
    const store = (0, import_blobs.getStore)("artdrop-beta");
    const claimsRaw = await store.get("persona-claims");
    if (claimsRaw) {
      const claims = JSON.parse(claimsRaw);
      for (const [persona, claimedBy] of Object.entries(claims)) {
        if (personaStatus.hasOwnProperty(persona)) {
          personaStatus[persona] = claimedBy;
        }
        if (testerStatus.hasOwnProperty(claimedBy)) {
          testerStatus[claimedBy].persona = persona;
        }
      }
    }
    for (const tester of ALL_TESTERS) {
      const stateRaw = await store.get(`tester-${tester.toLowerCase()}`);
      if (stateRaw) {
        const state = JSON.parse(stateRaw);
        testerStatus[tester].completed = Boolean(state.completed);
      }
    }
  } catch (err) {
    console.error("Blobs error in get-status:", err.message);
  }
  return new Response(
    JSON.stringify({ personas: personaStatus, testers: testerStatus }),
    { status: 200, headers: CORS }
  );
}
