var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/claim-persona.js
var claim_persona_exports = {};
__export(claim_persona_exports, {
  default: () => handler
});
module.exports = __toCommonJS(claim_persona_exports);
var import_blobs = require("@netlify/blobs");
var VALID_PERSONAS = /* @__PURE__ */ new Set([
  "Elena Vasquez",
  "Marcus Cole",
  "Janelle Torres",
  "David Okonkwo",
  "Own Artwork"
]);
var VALID_TESTERS = /* @__PURE__ */ new Set(["Kim", "Cassidy", "Marshall", "Mark", "Lisa", "Michael"]);
var CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
  "Content-Type": "application/json"
};
async function handler(req) {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: CORS });
  }
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), {
      status: 405,
      headers: CORS
    });
  }
  let body;
  try {
    body = await req.json();
  } catch {
    return new Response(JSON.stringify({ error: "Invalid JSON" }), {
      status: 400,
      headers: CORS
    });
  }
  const { tester, persona } = body;
  if (!tester || !persona) {
    return new Response(JSON.stringify({ error: "tester and persona are required" }), {
      status: 400,
      headers: CORS
    });
  }
  if (!VALID_TESTERS.has(tester)) {
    return new Response(JSON.stringify({ error: "Unknown tester" }), {
      status: 400,
      headers: CORS
    });
  }
  if (!VALID_PERSONAS.has(persona)) {
    return new Response(JSON.stringify({ error: "Unknown persona" }), {
      status: 400,
      headers: CORS
    });
  }
  const store = (0, import_blobs.getStore)("artdrop-beta");
  if (persona === "Own Artwork") {
    try {
      const testerStateRaw = await store.get(`tester-${tester.toLowerCase()}`);
      const testerState = testerStateRaw ? JSON.parse(testerStateRaw) : {};
      if (!testerState.completed) {
        return new Response(
          JSON.stringify({
            ok: false,
            error: "You need to complete a persona test before testing with your own artwork."
          }),
          { status: 403, headers: CORS }
        );
      }
    } catch (err) {
      console.error("Blobs error checking completed flag:", err.message);
      return new Response(
        JSON.stringify({ ok: false, error: "Server error checking eligibility." }),
        { status: 500, headers: CORS }
      );
    }
    return new Response(
      JSON.stringify({ ok: true, persona, tester }),
      { status: 200, headers: CORS }
    );
  }
  let claims;
  try {
    const claimsRaw = await store.get("persona-claims");
    claims = claimsRaw ? JSON.parse(claimsRaw) : {};
  } catch (err) {
    console.error("Blobs error reading persona-claims:", err.message);
    return new Response(
      JSON.stringify({ ok: false, error: "Server error reading claims." }),
      { status: 500, headers: CORS }
    );
  }
  const currentHolder = claims[persona];
  if (currentHolder === tester) {
    return new Response(
      JSON.stringify({ ok: true, persona, tester }),
      { status: 200, headers: CORS }
    );
  }
  if (currentHolder && currentHolder !== tester) {
    return new Response(
      JSON.stringify({
        ok: false,
        error: `${persona} is already claimed by ${currentHolder}.`,
        claimedBy: currentHolder
      }),
      { status: 409, headers: CORS }
    );
  }
  for (const [existingPersona, claimedBy] of Object.entries(claims)) {
    if (claimedBy === tester && existingPersona !== persona) {
      delete claims[existingPersona];
    }
  }
  claims[persona] = tester;
  try {
    await store.set("persona-claims", JSON.stringify(claims));
  } catch (err) {
    console.error("Blobs error writing persona-claims:", err.message);
    return new Response(
      JSON.stringify({ ok: false, error: "Server error saving claim." }),
      { status: 500, headers: CORS }
    );
  }
  return new Response(
    JSON.stringify({ ok: true, persona, tester }),
    { status: 200, headers: CORS }
  );
}
