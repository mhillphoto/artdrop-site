
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/tester-auth.js
import { getStore } from "@netlify/blobs";
var TESTERS = {
  kim: "Kim",
  cassidy: "Cassidy",
  marshall: "Marshall",
  mark: "Mark",
  elisa: "Elisa",
  jen: "Jen",
  michael: "Michael"
  // admin
};
var CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
  "Content-Type": "application/json"
};
async function handler(req) {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: CORS });
  }
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), {
      status: 405,
      headers: CORS
    });
  }
  let body;
  try {
    body = await req.json();
  } catch {
    return new Response(JSON.stringify({ error: "Invalid JSON" }), {
      status: 400,
      headers: CORS
    });
  }
  const password = (body.password || "").trim().toLowerCase();
  if (!password) {
    return new Response(JSON.stringify({ error: "Password required" }), {
      status: 400,
      headers: CORS
    });
  }
  const testerName = TESTERS[password];
  if (!testerName) {
    return new Response(JSON.stringify({ ok: false, error: "Wrong password" }), {
      status: 401,
      headers: CORS
    });
  }
  let claimedPersona = null;
  let completed = false;
  try {
    const store = getStore("artdrop-beta");
    const claimsRaw = await store.get("persona-claims");
    if (claimsRaw) {
      const claims = JSON.parse(claimsRaw);
      for (const [persona, claimedBy] of Object.entries(claims)) {
        if (claimedBy === testerName) {
          claimedPersona = persona;
          break;
        }
      }
    }
    const testerStateRaw = await store.get(`tester-${testerName.toLowerCase()}`);
    if (testerStateRaw) {
      const testerState = JSON.parse(testerStateRaw);
      completed = Boolean(testerState.completed);
    }
  } catch (err) {
    console.error("Blobs error in tester-auth:", err.message);
  }
  return new Response(
    JSON.stringify({
      ok: true,
      tester: testerName,
      claimed_persona: claimedPersona,
      completed
    }),
    { status: 200, headers: CORS }
  );
}
export {
  handler as default
};
