var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/tester-auth.js
var tester_auth_exports = {};
__export(tester_auth_exports, {
  default: () => handler
});
module.exports = __toCommonJS(tester_auth_exports);
var import_blobs = require("@netlify/blobs");
var TESTERS = {
  kim: "Kim",
  cassidy: "Cassidy",
  marshall: "Marshall",
  mark: "Mark",
  elisa: "Elisa",
  jen: "Jen",
  michael: "Michael"
  // admin
};
var CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
  "Content-Type": "application/json"
};
async function handler(req) {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: CORS });
  }
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), {
      status: 405,
      headers: CORS
    });
  }
  let body;
  try {
    body = await req.json();
  } catch {
    return new Response(JSON.stringify({ error: "Invalid JSON" }), {
      status: 400,
      headers: CORS
    });
  }
  const password = (body.password || "").trim().toLowerCase();
  if (!password) {
    return new Response(JSON.stringify({ error: "Password required" }), {
      status: 400,
      headers: CORS
    });
  }
  const testerName = TESTERS[password];
  if (!testerName) {
    return new Response(JSON.stringify({ ok: false, error: "Wrong password" }), {
      status: 401,
      headers: CORS
    });
  }
  let claimedPersona = null;
  let completed = false;
  try {
    const store = (0, import_blobs.getStore)("artdrop-beta");
    const claimsRaw = await store.get("persona-claims");
    if (claimsRaw) {
      const claims = JSON.parse(claimsRaw);
      for (const [persona, claimedBy] of Object.entries(claims)) {
        if (claimedBy === testerName) {
          claimedPersona = persona;
          break;
        }
      }
    }
    const testerStateRaw = await store.get(`tester-${testerName.toLowerCase()}`);
    if (testerStateRaw) {
      const testerState = JSON.parse(testerStateRaw);
      completed = Boolean(testerState.completed);
    }
  } catch (err) {
    console.error("Blobs error in tester-auth:", err.message);
  }
  return new Response(
    JSON.stringify({
      ok: true,
      tester: testerName,
      claimed_persona: claimedPersona,
      completed
    }),
    { status: 200, headers: CORS }
  );
}
