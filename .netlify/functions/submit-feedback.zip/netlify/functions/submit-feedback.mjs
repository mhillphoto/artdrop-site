
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/submit-feedback.js
import { getStore } from "@netlify/blobs";
var VALID_TESTERS = /* @__PURE__ */ new Set(["Kim", "Cassidy", "Marshall", "Mark", "Lisa", "Michael"]);
var VALID_AREAS = /* @__PURE__ */ new Set([
  "First Launch",
  "Setup Wizard",
  "Voice Training",
  "Templates",
  "First Drop",
  "Product Quality",
  "Collection & Organization",
  "Multiple Drops",
  "Overall Experience",
  "Bug Report",
  "Other"
]);
var VALID_SEVERITY = /* @__PURE__ */ new Set([
  "Worked great",
  "Minor issue",
  "Major issue",
  "Broken"
]);
var CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
  "Content-Type": "application/json"
};
async function handler(req) {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: CORS });
  }
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), {
      status: 405,
      headers: CORS
    });
  }
  let body;
  try {
    body = await req.json();
  } catch {
    return new Response(JSON.stringify({ error: "Invalid JSON" }), {
      status: 400,
      headers: CORS
    });
  }
  const { tester, persona, area, severity, description, device } = body;
  if (!tester || !persona || !area || !severity || !description) {
    return new Response(
      JSON.stringify({ error: "tester, persona, area, severity, and description are required" }),
      { status: 400, headers: CORS }
    );
  }
  if (!VALID_TESTERS.has(tester)) {
    return new Response(JSON.stringify({ error: "Unknown tester" }), {
      status: 400,
      headers: CORS
    });
  }
  if (!VALID_AREAS.has(area)) {
    console.warn(`submit-feedback: unknown area "${area}" from ${tester}`);
  }
  if (!VALID_SEVERITY.has(severity)) {
    console.warn(`submit-feedback: unknown severity "${severity}" from ${tester}`);
  }
  const timestamp = (/* @__PURE__ */ new Date()).toISOString();
  const feedbackKey = `feedback-${timestamp}-${tester.toLowerCase()}`;
  const record = {
    key: feedbackKey,
    timestamp,
    tester,
    persona,
    area,
    severity,
    description: description.trim(),
    device: (device || "").trim() || "Not specified"
  };
  let blobsOk = false;
  try {
    const store = getStore("artdrop-beta");
    await store.set(feedbackKey, JSON.stringify(record));
    blobsOk = true;
  } catch (err) {
    console.error("Blobs error in submit-feedback:", err.message);
  }
  let formsOk = false;
  try {
    const formBody = new URLSearchParams({
      "form-name": "artdrop-beta-feedback",
      "tester-name": tester,
      persona,
      area,
      severity,
      description: record.description,
      device: record.device
    });
    const siteUrl = process.env.URL || "http://localhost:8888";
    const formsRes = await fetch(siteUrl + "/", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: formBody.toString()
    });
    formsOk = formsRes.ok;
    if (!formsOk) {
      console.warn(`submit-feedback: Netlify Forms returned ${formsRes.status}`);
    }
  } catch (err) {
    console.warn("submit-feedback: Netlify Forms forward failed:", err.message);
  }
  if (!blobsOk && !formsOk) {
    return new Response(
      JSON.stringify({ ok: false, error: "Failed to save feedback. Please try again." }),
      { status: 500, headers: CORS }
    );
  }
  return new Response(
    JSON.stringify({ ok: true, key: feedbackKey, timestamp }),
    { status: 200, headers: CORS }
  );
}
export {
  handler as default
};
